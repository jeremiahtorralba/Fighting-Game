#pragma once
#include "Player.h"

class Enemy : public Player
{
private: double m_velX = 0,
	m_velY = 0,
	m_velMax = 10;
	double preJumpYVal;
	void MovePlayer(bool isFwd);
	void UpdatePlayer();
	void Jump();
	void OnJumpAnimationComplete();

public:
	Enemy(SDL_Texture* tex, double x, double y);
	~Enemy();
	void Update() override;
	void Render();
	void FlipEnemy();
	void MoveToPlayer();
	void FlippedMoveToPlayer();
	void EnemyDefense();
	void EnemyAttack();
	void EnemyHadouken();
	void EnemyHadouDefense();
};