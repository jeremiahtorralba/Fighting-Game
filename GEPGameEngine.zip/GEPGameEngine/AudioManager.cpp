#include <algorithm>
#include "AudioManager.h"
#include <iostream>

AudioManager::AudioManager() {
	
}

bool AudioManager:: Init() {
	if (Mix_Init(MIX_INIT_MP3) == 0)
	{
		cout << "Mixer init failed\n";
		return false;
	}
	else
	{
		Mix_OpenAudio(22050, AUDIO_S16SYS, 2, 4096);
		Mix_AllocateChannels(16);
		return true;
	}
}

void AudioManager::SetMusicVolume(int vollvl) {
	int clampedVolume =
	std::clamp(vollvl, 0, 128);

	Mix_VolumeMusic(clampedVolume);
}

void AudioManager::PlayMusic(int id, int loops) {
	Mix_PlayMusic(m_vMusicTracks[id], loops);
}

void AudioManager::PlaySound(int id, int channel, int loops) {
	Mix_PlayChannel(channel, m_vSounds[id], loops);
}

void AudioManager::LoadMusic(const char* path) {
	Mix_Music* t = Mix_LoadMUS(path);
	if (t != nullptr) {
		m_vMusicTracks.push_back(t);
	}
	else {
		cout << "Music load failed. \n"; //error
	}
}

void AudioManager::LoadSound(const char* path) {
	Mix_Chunk* t = Mix_LoadWAV(path);
	if (t != nullptr)
		m_vSounds.push_back(t);
	else
		cout << "Sound load failed. \n";
}

void AudioManager::ToggleMusic() {
	if (Mix_PausedMusic() == 1) //Mix_PausedMusic() returns 1 if paused.
		Mix_ResumeMusic();
	else
		Mix_PauseMusic();
}

void AudioManager::UnloadMusic() {
	//Mix_FreeMusic() //Unload a single music track from memory
	 
	//Unload entire vector:
	//iterate through vector, unload each index, and set its index to nullptr
	//after you do the above, clear vector & shrink to fit
}

void AudioManager::UnloadSound() {
	//Mix_FreeChunk() //Unload a single audio chunk from memory
}

AudioManager::~AudioManager() {
	UnloadMusic();
	UnloadSound();
	Mix_CloseAudio();
	Mix_Quit();
}