
#include "GameLevel1.h"
#include "Game.h"

void GameLevel1::Enter()
{

	bgSpriteTex = Game::Instance()->LoadTexture("Img/Levels/SF_Level_1.jpg");
	
	//call base class's Enter function
	GameState::Enter();
	// call different music here...
}

//In Exit function, add:
//Global cache for all loaded audio, 
//and a level specific cache that can be cleared when exiting a level

//Use AudioManager to have Global cache of music,track,sound,
//and a local cache of music,track,sound, 
//and make a mapping system using a label, to play back music,track,sound,