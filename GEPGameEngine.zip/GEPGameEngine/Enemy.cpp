#include "Enemy.h"
#include "Game.h"
#include <algorithm> //for min/max functions

Enemy::Enemy(SDL_Texture* tex, double x, double y)
	: Player(tex, x, y)
{
	//spriteSrcRect = { 0,0,70,80 };
	//spriteDestRect = { (int)(m_X - 50),(int)(m_Y - 50)  ,70,80 };
	m_velX = 1.5f;
	m_velY = 2.5f;
	m_dRadius = 50;

	AddAnimState("Hadouken", AnimStateDefinition(0, 4, 120));
	AddAnimState("Idle", AnimStateDefinition(1, 4, 120, true));
	AddAnimState("Punch", AnimStateDefinition(2, 3, 120));
	AddAnimState("Move", AnimStateDefinition(3, 5, 120, true));
	AddAnimState("Kick", AnimStateDefinition(6, 5, 120));
	AddAnimState("Roundhouse", AnimStateDefinition(7, 5, 120));
	AddAnimState("Jump", AnimStateDefinition(8, 7, 120));
	AddAnimState("Crouch", AnimStateDefinition(9, 1, 120));
	AddAnimState("Block", AnimStateDefinition(8, 3, 120)); //b. Optionally, you can add another defensive technique for + 2 % bonus.
	AddAnimState("Hit", AnimStateDefinition(0, 1, 120)); //(randomly decide if it wants to take a hit or defend)

	animStates["Jump"].RegisterOnAnimCompleteCallback(
		std::bind(&Enemy::OnJumpAnimationComplete, this));
}

Enemy::~Enemy()
{
}

void Enemy::Render()
{
	//this->SpriteExAnimated::Render(); //invoke the base class's Render()
	if (SDL_RenderCopyEx(Game::Instance()->GetRenderer(), texture,
		&spriteSrcRect, &spriteDestRect, angle, nullptr, (isFlipped ? SDL_FLIP_HORIZONTAL : SDL_FLIP_HORIZONTAL)) == 0)
	{
		std::cout << "Success Flipped Enemy Spawned...\n";
	}
	else
	{
		std::cout << "Failed to render..\n";
	}
}

void Enemy::FlipEnemy()
{
	SDL_RendererFlip flip = SDL_FLIP_NONE;
	SDL_RenderCopyEx(Game::Instance()->GetRenderer(), texture, &spriteSrcRect, &spriteDestRect, angle, nullptr, flip);
}

void Enemy::MoveToPlayer()  
{//b.The enemy should be able to move forward and attack the player on its own, if the player does not move towards it.
	int step = rand() % 17;
	if (step == 1) {
		m_X += m_velX - 4.2f;
		this->PlayState("Move");
	}
	if (Game::Instance()->KeyDown(SDL_SCANCODE_D)) {
		m_X += m_velX - 1.0f;
		int step = rand() % 5;
		if (step == 1) {
			this->PlayState("Move");
		}
	}
}

void Enemy::FlippedMoveToPlayer()
{//b.The enemy should be able to move forward and attack the player on its own, if the player does not move towards it.
	int step = rand() % 3;
	if (step == 1) {
		m_X += m_velX - 0.9f;
		this->PlayState("Move");
	}
	if (Game::Instance()->KeyDown(SDL_SCANCODE_A)) {
		m_X -= m_velX - 1.0f;
		int step = rand() % 5;
		if (step == 1) {
			this->PlayState("Move");
		}
	}
}

void Enemy::EnemyDefense() // Enemy Defensive Mechanism:
{	
	if (Game::Instance()->KeyDown(SDL_SCANCODE_X) || Game::Instance()->KeyDown(SDL_SCANCODE_C) || Game::Instance()->KeyDown(SDL_SCANCODE_V) || Game::Instance()->KeyDown(SDL_SCANCODE_B) && this)
	{
		int hitdef = rand() % 5;
		if (hitdef == 2) {
			int hit = rand() % 2;
			if (hit == 1) {
				this->PlayState("Hit"); //(randomly decide if it wants to take a hit or defend)
			}
		}
		else if (hitdef == 3) {
			int cro = rand() % 2;
			if (cro == 1) {
				this->PlayState("Crouch"); //a. Enemy can defend by crouching. 
			}
		}
		else if (hitdef == 3) {
			int blo = rand() % 2;
			if (blo == 1) {
				this->PlayState("Block"); //b. Optionally, you can add another defensive technique for + 2 % bonus.
			}
		}
		else if (hitdef == 4) {
			int jump = rand() % 4;
			if (jump == 1) {
				if (this->currentState != "Jump")
					preJumpYVal = m_Y;
				this->PlayState("Jump");
			}
		}
	}
}

void Enemy::EnemyHadouDefense() // Enemy Defensive Mechanism:
{
	if (Game::Instance()->KeyDown(SDL_SCANCODE_B))
	{
		int hitdef = rand() % 5;
		if (hitdef == 2) {
			int hit = rand() % 2;
			if (hit == 1) {
				this->PlayState("Hit"); //(randomly decide if it wants to take a hit or defend)
			}
		}
		else if (hitdef == 3) {
			int cro = rand() % 2;
			if (cro == 1) {
				this->PlayState("Crouch"); //a. Enemy can defend by crouching. 
			}
		}
		else if (hitdef == 3) {
			int blo = rand() % 2;
			if (blo == 1) {
				this->PlayState("Block"); //b. Optionally, you can add another defensive technique for + 2 % bonus.
			}
		}
		else if (hitdef == 4) {
			int jump = rand() % 4;
			if (jump == 1) {
				if (this->currentState != "Jump")
					preJumpYVal = m_Y;
				this->PlayState("Jump");
			}
		}
	}
}

void Enemy::EnemyAttack()
{ /* I) Attack-Defend Logic (35%): Enemy Attack Mechanism: */
	int attack = rand() % 6; // The attack chosen can be randomized.
		if (attack == 3) {
			int punch = rand() % 3;
			if (punch == 1) {
				this->PlayState("Punch");
			}
		}
		else if (attack == 2) {
			int roundh = rand() % 3;
			if (roundh == 1) {
				this->PlayState("Roundhouse");
			}
		}
		else if (attack == 2) {
			int kick = rand() % 3;
			if (kick == 1) {
				this->PlayState("Kick");
			}
		}
		else if (attack == 2) {
			int hadou = rand() % 50;
			if (hadou == 1) {
				this->PlayState("Hadouken");
			}
		}
		else if (attack == 5) {
			this->PlayState("Idle");
		}
}

void Enemy::EnemyHadouken()
{ //d.Hadouken : -30 (You need to instantiate a sprite
	//(just like missile in asteroid game) when you use
	//Hadouken and destroy when it either hits the opponent
	//or when it goes out of screen)
	int hadou = rand() % 400;
	if (hadou == 1) {
		this->PlayState("Hadouken");
	}
}

void Enemy::Update()
{
	this->PlayState("Idle");
	if (currentState == "Jump")
		Jump();
	this->spriteSrcRect.x = spriteSrcRect.w * m_iFrame;
	this->UpdateDestRect();
}

void Enemy::MovePlayer(bool isFwd)
{
	if (isFwd)
		m_X += m_velX;
	else
		m_X -= m_velX;
	this->PlayState("Move");
}

void Enemy::Jump()
{
	if (m_iFrame < 3)
	{
		m_Y -= m_velY;
	}
	else if (m_iFrame > 3)
	{
		m_Y += m_velY;

		if (m_Y > preJumpYVal)
			m_Y = preJumpYVal;
	}
}

void Enemy::OnJumpAnimationComplete()
{
	cout << "Jump animation is completed. reset player to preJumpY val\n";
	if (m_Y > preJumpYVal)
		m_Y = preJumpYVal;
}