#include "Player.h"
#include "Game.h"
#include <algorithm> //for min/max functions

Player::Player(SDL_Texture *tex, double x, double y)
	: SpriteExAnimated(tex, x - 50, y - 50, 0, 1, 4, 0.1f)
{
	//spriteSrcRect = { 0,0,70,80 };
	//spriteDestRect = { (int)(m_X - 50),(int) (m_Y-50)  ,70,80 };
	m_velX = 1.5f;
	m_velY = 2.5f;
	m_dRadius = 50;

	AddAnimState("Hadouken", AnimStateDefinition(0, 4, 120));
	AddAnimState("Idle", AnimStateDefinition(1, 4, 120, true));
	AddAnimState("Punch", AnimStateDefinition(2, 3, 120));
	AddAnimState("Move", AnimStateDefinition(3, 5, 120, true));
	AddAnimState("Kick", AnimStateDefinition(6, 5, 120));
	AddAnimState("Roundhouse", AnimStateDefinition(7, 5, 120));
	AddAnimState("Jump", AnimStateDefinition(8, 7, 120));
	AddAnimState("Crouch", AnimStateDefinition(9, 1, 120));

	animStates["Jump"].RegisterOnAnimCompleteCallback(
		std::bind(&Player::OnJumpAnimationComplete, this) );
}

Player::~Player()
{ 
}

void Player::Render()
{
this->SpriteExAnimated::Render(); //invoke the base class's Render()
}

void Player::FlipPlayer()
{
	SDL_RendererFlip flip = SDL_FLIP_HORIZONTAL;
	SDL_RenderCopyEx(Game::Instance()->GetRenderer(), texture, &spriteSrcRect, &spriteDestRect, angle, nullptr, flip);
}

void Player::Update()
{ 
	this->UpdatePlayer();
 }

void Player::MovePlayer(bool isFwd)
{
	if (isFwd)
		m_X += m_velX;
	else
		m_X -= m_velX;

	this->PlayState("Move");
}

void Player::Jump()
{
	if (m_iFrame < 3)
	{
		m_Y -= m_velY;
	}
	else if (m_iFrame > 3)
	{
		m_Y += m_velY;

		if (m_Y > preJumpYVal)
			m_Y = preJumpYVal;
	}
}

void Player::OnJumpAnimationComplete()
{
	cout << "Jump animation is completed. reset player to preJumpY val\n";
	if (m_Y > preJumpYVal)
	m_Y = preJumpYVal;
}

void Player::UpdatePlayer()
{
	// Player Moves: 
	// a. Player must be able to use all moves as below;		
	if (Game::Instance()->KeyDown(SDL_SCANCODE_D))
		MovePlayer(true);
	else if (Game::Instance()->KeyDown(SDL_SCANCODE_A))
		MovePlayer(false);
	else if (Game::Instance()->KeyDown(SDL_SCANCODE_W)) // including proper Jumping mechanism. 
	{
		if (this->currentState != "Jump")
			preJumpYVal = m_Y;

		this->PlayState("Jump");

	}
	else if (Game::Instance()->KeyDown(SDL_SCANCODE_S))
	{
		this->PlayState("Crouch");
	}
	else if (Game::Instance()->KeyDown(SDL_SCANCODE_X))
	{
		this->PlayState("Punch"); //to-do:: play punch animation
	}
	else if (Game::Instance()->KeyDown(SDL_SCANCODE_C))
	{
		this->PlayState("Roundhouse");
	}
	else if (Game::Instance()->KeyDown(SDL_SCANCODE_V))
	{
		this->PlayState("Kick");
	}
	else if (Game::Instance()->KeyDown(SDL_SCANCODE_B))
	{
		this->PlayState("Hadouken");
	}
	else 
	{
		this->PlayState("Idle"); //play idle animation
	}
	if(currentState=="Jump")
		Jump();
	spriteSrcRect.x = spriteSrcRect.w * m_iFrame;
	this->UpdateDestRect();
}