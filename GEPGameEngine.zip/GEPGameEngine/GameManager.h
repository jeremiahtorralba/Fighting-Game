#pragma once
#include <iostream>
#include <string>
#include <algorithm>
#include <SDL.h>
#include <SDL_ttf.h> // to render ttf fonts
#include "GameState.h"
using namespace std;

// II) Health System (10%):
// keep track of scoring
// keep track of health 
// keep track of etc.

// Each player starts off with 100% health at the beginning of 
//the game.

// Health Scoring works like this:
// a.Punch : -5
// b.Kick : -10
// c.Roudhouse Kick : -15
// d.Hadouken : -30 (You need to instantiate a sprite
// (just like missile in asteroid game) when you use
//Hadouken and destroy when it either hits the opponent
//or when it goes out of screen)

class GameManager : public GameState
{
private:
	SDL_Event event; // to handle events
	SDL_Window* window; // moved from InitGameEngine
	SDL_Renderer* renderer;
	TTF_Font* font; // font declarations
	SDL_Surface* fontSurface;
	SDL_Texture* fontTexture;
	SDL_Rect textRectScore; // defines 'score' text on screen
	void RenderFont(const char* text, int x, int y, bool isRefreshText); // font related function
	int ehealth = 100;
	int phealth = 100;
	string s1 = to_string(ehealth);
	string s2 = to_string(phealth);
	string aiwins = ".";
	string p1wins = ".";
	SDL_Rect hide1;
	SDL_Rect hide2;


public:
	static GameState* Instance(); // function returns
	void DamageEnemy();
	void DamagePlayer();
	void KeepPlayerHealth();
	void KeepEnemyHealth();
	void PlayerWins();
	void EnemyWins();
	void InitGameWorld();
	void Render();
	void Quit();
	void Update();
};