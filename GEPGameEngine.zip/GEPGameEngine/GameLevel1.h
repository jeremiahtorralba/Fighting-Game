#pragma once
#include "GameState.h"

class GameLevel1 : public GameState
{
public:
	GameLevel1() {}

	void Enter() override;
};