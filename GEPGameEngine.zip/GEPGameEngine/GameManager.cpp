#include "GameManager.h"
static GameState* instance; // Singleton pattern for GameEngine class, static instance

void GameManager::RenderFont(const char* text, int x, int y, bool isRefreshText)
{
	if (isRefreshText) {
		SDL_Color textColor = { 255, 255, 255, 255 }; // white
		fontSurface = TTF_RenderText_Solid(font, text, textColor);

		if (fontTexture) // de-allocate previously assigned font texture, if any
			SDL_DestroyTexture(fontTexture);

		fontTexture = SDL_CreateTextureFromSurface(renderer, fontSurface);
		textRectScore = { x, y, fontSurface->w, fontSurface->h };
	}
	SDL_RenderCopy(renderer, fontTexture, 0, &textRectScore); // draws the font
}

GameState* GameManager::Instance()
{
	if (instance == nullptr)
		instance = new GameState();
	return instance;
}

void GameManager::DamageEnemy() { // 
	ehealth--;
	s1 = to_string(ehealth);
	RenderFont(s1.c_str(), 190, 70, true);
	cout << "Enemy damaged by: \n" + s1;
}

void GameManager::DamagePlayer() { //
	phealth--;
	s2 = to_string(phealth);
	RenderFont(s2.c_str(), 595, 30, true);
	cout << "Player damaged by: \n" + s2;
}

void GameManager::KeepPlayerHealth() { // Game-End Condition:
	if (phealth == 0) {
		EnemyWins();
	}
}

void GameManager::KeepEnemyHealth() { // Game-End Condition:
	if (ehealth == 0) {
		PlayerWins();
	}
}

void GameManager::PlayerWins() { // Game-End Condition: Player wins
	p1wins = "PLAYER WINS! " + s1 + " - " + s2;
	RenderFont(p1wins.c_str(), 35, 70, true);
}

void GameManager::EnemyWins() { // Game-End Condition: Enemy wins
	aiwins = "ENEMY WINS! " + s2 + " - " + s1;
	RenderFont(aiwins.c_str(), 460, 60, true);
}

void GameManager::InitGameWorld() {
	font = TTF_OpenFont("GEPGameEngine/Fonts/LTYPE.TTF", 30); // initial size of 30, LTYPE.TTF file placed in created Assets/Fonts folders
	hide1.x = 42;
	hide1.y = 94;
	hide1.w = 5;
	hide1.h = 5;
	hide2.x = 456;
	hide2.y = 94;
	hide2.w = 5;
	hide2.h = 5;
}

void GameManager::Render() {
	SDL_RenderClear(renderer); // Clears the previously drawn frame, Draw current frame:
	RenderFont(s1.c_str(), 190, 30, true); // render player's score  
	RenderFont(s2.c_str(), 595, 30, true); // render ai's score 
	RenderFont(p1wins.c_str(), 35, 70, true); // player's win statement
	RenderFont(aiwins.c_str(), 450, 70, true); // ai's win statement
	SDL_SetRenderDrawColor(renderer, 63, 72, 204, 255); // indigo
	SDL_RenderFillRect(renderer, &hide1); // hide1
	SDL_SetRenderDrawColor(renderer, 63, 72, 204, 255); // indigo
	SDL_RenderFillRect(renderer, &hide2); // hide2
	SDL_RenderPresent(renderer); // must call this to render all of the above
}

void GameManager::Quit() {
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
	SDL_Quit(); // shutdown SDL, any clearing of properties should be placed here
	TTF_CloseFont(font);
	TTF_Quit();
}

void GameManager::Update() {
	void KeepPlayerHealth(); // Game-End Condition:
	void KeepEnemyHealth(); // Game-End Condition:
}