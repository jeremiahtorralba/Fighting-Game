#pragma once
#include <vector>
#include "SDL_mixer.h"
using namespace std;

class AudioManager {
private:
	vector<Mix_Music*> m_vMusicTracks;
	vector<Mix_Chunk*> m_vSounds;

public: 
	AudioManager();
	~AudioManager();
	bool Init();
	void SetMusicVolume(int vollvl); // set music volume
	void PlayMusic(int id, int loops = -1); // loops = -1 meand infinite
	void PlaySound(int id, int channel = -1, int loops = 0);
	void LoadMusic(const char* path);
	void LoadSound(const char* path);
	void UnloadMusic();
	void UnloadSound();
	void ToggleMusic(); // Toggle Music
};